#!/usr/bin/env python3
from GoogleSheet import *
from ImportToOpenSongSet import *
from appdirs import *
from pathlib import Path
from os.path import *
from tkinter.filedialog  import askopenfilename
from configparser import ConfigParser
from tkinter import ttk
import tkinter as tk
import locale
from  .LilyPondRenderServer import *

class ConfigEntry(tk.StringVar):
    def __init__(self, configuration, section, entry):
        tk.StringVar.__init__(self)
        self.configuration = configuration
        self.section = section
        self.entry = entry
        self.trace('w', self.vartrace)
    
    def set(self, value):
        if self.configuration[self.section][self.entry] != value:
            self.configuration[self.section][self.entry] = value
            self.configuration.changed = True
        if tk.StringVar.get(self) != value:
            tk.StringVar.set(self, value)

    def get(self):
        return self.configuration[self.section][self.entry]
    
    def vartrace(self, *args):
        self.set(tk.StringVar.get(self))

class Configuration(ConfigParser):

    CFG_SECTION_GENERIC     = 'Generic'
    CFG_LANGUAGE            = 'language'

    CFG_SECTION_SERVER      = 'Server'
    CFG_PORT                = 'port'
    CFG_HOST                = 'host'
    CFG_THREADS             = 'threads'

    CFG_SECTION_LILYPOND    = 'LilyPond'
    CFG_TEMPLATE            = 'template'
    CFG_COMMAND             = 'command'
    CFG_WORKDIR             = 'workdir'
    CFG_CACHEDIR            = 'cachedir'
    CFG_KEEPLY              = 'keeply'

    def __init__(self):
        ConfigParser.__init__(self, allow_no_value=True)

        # Set the defaults
        self[self.CFG_SECTION_GENERIC] = {
            self.CFG_LANGUAGE : 'English'
        }
        self[self.CFG_SECTION_SERVER] = {
            self.CFG_PORT : LilyPondRenderServer.defaultport,
            self.CFG_HOST : LilyPondRenderServer.defaulthost,
            self.CFG_THREADS : LilyPondRenderServer.DefaultThreadCount()
        }
        self[self.CFG_SECTION_LILYPOND] = {
            self.CFG_TEMPLATE : LilyPondRenderServer.defaulttemplate,
            self.CFG_COMMAND : LilyPondRenderServer.defaultcommand,
            self.CFG_WORKDIR : LilyPondRenderServer.DefaultWorkDir(),
            self.CFG_CACHEDIR : LilyPondRenderServer.DefaultCacheDir,
            self.CFG_KEEPLY : 'false'
        }
        self.changed = True
        self.appname = 'LilyPondRenderServer'
        self.appauthor='OpenSong'
        self.cachedir = user_cache_dir(self.appname, self.appauthor)
        os.makedirs(self.cachedir, exist_ok=True)

        # Load from file, if it exists. Otherwise, create.
        self.file = Path(user_data_dir(self.appname, self.appauthor))
        if not self.file.exists():
            self.file.mkdir(parents=True)
        self.file = self.file / 'settings.cfg'
        if self.file.is_file():
            with self.file.open() as file:
                self.read_file(file)
            self.changed = False
        else:
            self.WriteIfChanged()

    def WriteIfChanged(self):
        if self.changed:
            with self.file.open(mode='w') as file:
                self.write(file)
            self.changed = False

class Application(tk.Frame):
    
    padsize = 3

    def __init__(self, master=None):
        tk.Frame.__init__(self, master)

        self.configuration = Configuration()
        self.cfg_geometry = ConfigEntry(self.configuration, Configuration.CFG_SECTION_VARIOUS, Configuration.CFG_GEOMETRY)
        self.pack(fill=tk.BOTH, expand=tk.YES)
        self.actions = ActionsFrame(self)
        self.actions.pack(side=tk.TOP, fill=tk.BOTH, expand=tk.YES)
        # ttk.Separator(self, orient=tk.VERTICAL).pack(side=tk.LEFT, fill=tk.Y, padx=5)
        self.config = ConfigurationFrame(self)
        self.config.pack(side=tk.TOP, fill=tk.X, expand=tk.NO, padx=self.padsize, pady=self.padsize)
        root.geometry(self.cfg_geometry.get())
        root.protocol("WM_DELETE_WINDOW", self.OnClose)

    def OnClose(self):
        self.cfg_geometry.set(root.geometry())
        root.destroy()

class ActionsFrame(tk.Frame):
    def __init__(self, master=None):
        tk.Frame.__init__(self, master)
        self.columnconfigure(1, weight=1)
        self.rowconfigure(2, weight=1)
        self.folder = ''

        # The main controls for 'daily' use
        self.btn_start = tk.Button(self, text='Start server', command=self.Start)
        self.btn_start.grid(row=1, column=1)
        self.btn_stop = tk.Button(self, text='Stop server', command=self.Stop)
        self.btn_stop.grid(row=1, column=1)

        # Add a log area to the GUI        
        frame = tk.Frame(self)
        frame.grid(row=2, column=0, columnspan=2, padx=master.padsize, pady=master.padsize, sticky=tk.NSEW)
        self.txt_output = tk.Text(frame, wrap=tk.WORD, state=tk.DISABLED, height=4)
        self.txt_output.pack(side=tk.LEFT, fill=tk.BOTH, expand=tk.YES)
        self.txt_output.tag_config("error", foreground="red")
        scrollbar = tk.Scrollbar(frame)
        scrollbar.pack(side=tk.LEFT, fill=tk.Y)
        scrollbar.config(command=self.txt_output.yview)
        self.txt_output.config(yscrollcommand=scrollbar.set)

    def Start(self):
        Log('Server started')
        pass

    def Stop(self):
        Log('Server stopped')
        pass

    def Log(self, text, error=False):
        self.txt_output.configure(state=tk.NORMAL)
        tags = ()
        if error:
            tags = ("error")
        self.txt_output.insert(tk.END, text + '\n', tags)
        self.txt_output.configure(state=tk.DISABLED)
        self.txt_output.see(tk.END)
        self.txt_output.update_idletasks()

class GenericConfigurationFrame(tk.LabelFrame):
    def __init__(self, master=None):
        tk.LabelFrame.__init__(self, master, text='Generic settings')
        self.columnconfigure(1, weight=1)
        gridrow = 0
        self.language = ttk.Combobox(self)
        widget_entries = [ ('Language', Configuration.CFG_LANGUAGE) ]
        for label, configname in widget_entries:
            PvBWidget(self, label, gridrow, configentry=ConfigEntry(master.configuration, Configuration.CFG_SECTION_VARIOUS, configname),
                        fileselection=False, textlen=15)
            gridrow += 1

class ServerConfigurationFrame(tk.LabelFrame):
    def __init__(self, master=None):
        tk.LabelFrame.__init__(self, master, text='Instellingen')
        self.columnconfigure(1, weight=1)
        gridrow = 0
        self.language = ttk.Combobox(self)
        widget_entries = [ ('Mededelingen periode (dagen)', Configuration.CFG_DEFAULT_DAYS),
                           ('Afwijkende locale',            Configuration.CFG_LOCALE) ]
        for label, configname in widget_entries:
            PvBWidget(self, label, gridrow, configentry=ConfigEntry(master.configuration, Configuration.CFG_SECTION_VARIOUS, configname),
                        fileselection=False, textlen=15)
            gridrow += 1

class LilyPondConfigurationFrame(tk.LabelFrame):
    def __init__(self, master=None):
        tk.LabelFrame.__init__(self, master, text='Instellingen')
        self.columnconfigure(1, weight=1)
        gridrow = 0
        self.language = ttk.Combobox(self)
        widget_entries = [ ('Mededelingen periode (dagen)', Configuration.CFG_DEFAULT_DAYS),
                           ('Afwijkende locale',            Configuration.CFG_LOCALE) ]
        for label, configname in widget_entries:
            PvBWidget(self, label, gridrow, configentry=ConfigEntry(master.configuration, Configuration.CFG_SECTION_VARIOUS, configname),
                        fileselection=False, textlen=15)
            gridrow += 1


root = tk.Tk()
app = Application()
app.master.title('OpenSong sets aanvullen vanuit (google) csv files')
app.mainloop()             
app.configuration.WriteIfChanged()
