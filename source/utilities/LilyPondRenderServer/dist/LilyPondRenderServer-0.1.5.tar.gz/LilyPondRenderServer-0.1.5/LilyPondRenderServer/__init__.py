from .LilyPondRenderServer import runserver

def main():
    runserver()