A rendering server for OpenSong using LilyPond to render songs with musical notes
=================================================================================

The current version is preliminary. The format in which notes are stored
in the OpenSong database can still change and definetely will be extended.


